import edu.princeton.cs.algs4.WeightedQuickUnionUF;
/**
 * Created by Victor Avelar on 6/4/2019
 * This new version deals with backwash by creating another instance of WeightedQuickUnionUF, whilest the first version
 * failed the backwash test.
 */
public class Percolation{
    private WeightedQuickUnionUF uf;
    private WeightedQuickUnionUF backwashUF;
    private boolean[][] grid;
    private int openSites = 0;
    private int n;
    private final int TOP, BOTTOM;

    // create n-by-n grid, with all sites blocked
    public Percolation(int n){ //throws IllegalArgumentException {
//        if(n <= 0){
//            throw new IllegalArgumentException("n cannot be smaller than 1");
//        }
        this.grid = new boolean[n+1][n+1];
        //(n*n)+1 designated as imaginary point linking all the top points
        this.uf = new WeightedQuickUnionUF((n*n)+2);
        this.backwashUF = new WeightedQuickUnionUF(n*n+2);
        uf.union(backwashUF.find(1), n);
        this.n = n;
        TOP = (n*n);
        BOTTOM = (n*n)+1;
        //top row with single point
        for (int i = 0; i < n; i++) {
            union(TOP,i);
        }

        //bottom row with single point
        for (int i = (n*(n-1)); i < n*n-1; i++) {
            backwashUF.union(BOTTOM, i);
        }

    }
    // open site (row, col) if it is not open already
    public void open(int row, int col) {
        validateBounds(row, col);

        if(!grid[row][col]){
            grid[row][col] = true;
            openSites++;

            //connects to top if open
            if(row != 1 && grid[row-1][col]){
                //System.out.println("connected to top");
                union(convertRowColTo1dIndex(row, col), convertRowColTo1dIndex(row-1, col));
            }
            //connects to right if open
            if(col != n){
                if(grid[row][col+1]) {
                    //System.out.println("connected to the right");
                    union(convertRowColTo1dIndex(row, col), convertRowColTo1dIndex(row, col+1));
                }
            }
            //connects to left if open
            if(col != 1){
                if(grid[row][col-1]){
                    //System.out.println("connected to the left");
                    union(convertRowColTo1dIndex(row, col), convertRowColTo1dIndex(row, col-1));
                }
            }
            //connects to bottom if open
            if(row != n){
                if(grid[row+1][col]){
                    //System.out.println("connected to the bottom");
                    union(convertRowColTo1dIndex(row, col), convertRowColTo1dIndex(row+1, col));
                }
            }

        }
    }
    // is site (row, col) open?
    public boolean isOpen(int row, int col){
        //validateBounds(row, col);
        return grid[row][col];
    }
    // is site (row, col) full?
    public boolean isFull(int row, int col){
        validateBounds(row, col);
        return uf.connected(convertRowColTo1dIndex(row,col), TOP) && isOpen(row,col);
    }
    // number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }
    // does the system percolate?
    public boolean percolates() {
        return backwashUF.connected(TOP, BOTTOM);
    }
    private void validateBounds(int row, int col) {//throws IllegalArgumentException{
//        if(row <= 0 || row > n || col <= 0 || col > n){
//            throw new IllegalArgumentException("row and col must be inclusively in the range of 1 and n");
//        }
    }
    //convert 2d array index i(1 <= i <= n) to 1d array index i (0 <= i < n)
    private int convertRowColTo1dIndex(int row, int col){
        //System.out.println("row "+row+" col "+col +"to " + (((row-1)*n)+(col-1)));
        return ((row-1)*n)+(col-1);
    }
    private void union(int row, int col){
        uf.union(row, col);
        backwashUF.union(row, col);
    }
    //test client (optional)
    public static void main(String[] args){

    }
}
